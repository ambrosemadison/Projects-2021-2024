import os
import sys

import CosNaming
from omniORB import CORBA

import WordyGame
from GUI_Client import GUI_Client

class Client:
    def __init__(self):
        # Set the ORB configuration using environment variables
        self.args = ['-ORBInitRef', "NameService=corbaloc::192.168.100.212:10000/NameService"]
        # Initialize the ORB
        orb = CORBA.ORB_init(self.args, CORBA.ORB_ID)
        obj = orb.resolve_initial_references("NameService")
        rootContext = obj._narrow(CosNaming.NamingContext)
        if rootContext is None:
            sys.exit(1)
        name = [CosNaming.NameComponent("Server", "")]
        try:
            obj = rootContext.resolve(name)
        except CosNaming.NamingContext.NotFound as ex:
            sys.exit(1)
        self.servant = obj._narrow(WordyGame.WordyGameIDL)

    def run(self):
        # Create and run the GUI_Client
        gui_client = GUI_Client(self.servant)
        gui_client.mainFrame()


if __name__ == "__main__":
    client = Client()
    client.run()