class Hello:
    @staticmethod
    def main():
        print("Goodbye World")
        print("HELLO WORLD")

Hello.main()