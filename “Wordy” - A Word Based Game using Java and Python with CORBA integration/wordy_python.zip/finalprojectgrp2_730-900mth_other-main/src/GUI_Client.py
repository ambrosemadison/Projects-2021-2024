import threading
import time
import tkinter as tk
import traceback
from tkinter import messagebox, Entry, Button, Text, Toplevel, Frame, Scrollbar, Label

from PIL import ImageTk, Image

import WordyGame


class GUI_Client:
    def __init__(self, servant):
        self.wordTF = None
        self.spgWindow = None
        self.leadb = None
        self.homeWindowInstance = None
        self.passwordTF = None
        self.usernameTF = None
        self.ogWindow = None
        self.servant = servant
        self.clientWindow = None
        self.currentTimer = 10
        self.Text = None
        self.timer = None
        self.timeLeft = None
        self.joinedGameObject = None

    def setLoginButton(self):
        if self.usernameTF.get() == "" and self.passwordTF.get() == "":
            messagebox.showinfo("Login Error", "Please enter a username and a password.")
        elif self.usernameTF.get() == "":
            messagebox.showinfo("Login Error", "Please enter your username.")
        elif self.passwordTF.get() == "":
            messagebox.showinfo("Login Error", "Please enter your password.")
        else:
            try:
                self.servant.login(self.usernameTF.get(), self.passwordTF.get())
                messagebox.showinfo("Login Success", "Login Successful!")
                self.homeWindow()
                if self.clientWindow:
                    self.clientWindow.destroy()

            except WordyGame.WordyGameException as ex:
                messagebox.showinfo("Login Error", "Login Unsuccessful: " + str(ex))

    def mainFrame(self):
        self.clientWindow = tk.Tk()
        self.clientWindow.title("W O R D Y    G A M E")
        self.clientWindow.geometry("715x500")
        self.clientWindow.resizable(False, False)

        background_image = Image.open("bgtitle.png")
        background_photo = ImageTk.PhotoImage(background_image)

        background_label = tk.Label(self.clientWindow, image=background_photo)
        background_label.place(x=0, y=0, relwidth=1, relheight=1)

        titleLogin = tk.Label(self.clientWindow, text="Login", font=("Serif", 20, "bold"))
        titleLogin.place(x=357, y=220, relheight=0.10)

        usernameLabel = tk.Label(self.clientWindow, text="Username")
        usernameLabel.place(x=185, y=280, relheight=0.05)

        self.usernameTF = Entry(self.clientWindow)
        self.usernameTF.place(x=250, y=280, relwidth=0.5, relheight=0.06)

        passwordLabel = tk.Label(self.clientWindow, text="Password")
        passwordLabel.place(x=185, y=355, relheight=0.05)

        self.passwordTF = Entry(self.clientWindow, show="*")
        self.passwordTF.place(x=250, y=350, relwidth=0.5, relheight=0.06)

        loginButton = Button(self.clientWindow, text="Login", command=self.setLoginButton)
        loginButton.place(x=295, y=430, relwidth=0.28, relheight=0.06)

        self.clientWindow.mainloop()

    def homeWindow(self):
        if self.clientWindow and self.clientWindow.winfo_exists():
            self.clientWindow.withdraw()

        self.homeWindowInstance = Toplevel()
        self.homeWindowInstance.title("Home Window")
        self.homeWindowInstance.geometry("715x550")
        self.homeWindowInstance.resizable(False, False)

        background_image = Image.open("bgtitle.png")
        background_photo = ImageTk.PhotoImage(background_image)
        background_label = tk.Label(self.homeWindowInstance, image=background_photo)
        background_label.place(x=0, y=0, relwidth=1, relheight=1)

        playGame = Button(self.homeWindowInstance, text="Play Game", font=("Serif", 25, "bold"), fg="#FF66C4",
                          bg="#DCFB01", command=self.setPlayGame)
        playGame.place(x=215, y=280, relwidth=0.5, relheight=0.05)

        leaderboards = Button(self.homeWindowInstance, text="LEADERBOARDS", font=("Serif", 25, "bold"), fg="#FF66C4",
                              bg="#DCFB01", command=self.setLeaderboards)
        leaderboards.place(x=215, y=350, relwidth=0.5, relheight=0.05)

        logoutButton = Button(self.homeWindowInstance, text="LOGOUT", font=("Serif", 25, "bold"), fg="#FF66C4",
                              bg="#DCFB01",
                              command=self.setLogoutButton)
        logoutButton.place(x=215, y=430, relwidth=0.5, relheight=0.05)

        self.homeWindowInstance.mainloop()

    def setLogoutButton(self):
        self.servant.logout(self.usernameTF.get())
        messagebox.showinfo("Logout", "Logout Successful for User " + self.usernameTF.get())
        self.homeWindowInstance.destroy()
        self.spgWindow.destroy()

    def setPlayGame(self):
        self.homeWindowInstance.destroy()

        self.spgWindow = Toplevel()
        self.spgWindow.title("PlayGame")
        self.spgWindow.geometry("715x550")
        self.spgWindow.resizable(False, False)

        background_image = Image.open("bgwait.png")
        background_photo = ImageTk.PhotoImage(background_image)
        background_label = tk.Label(self.spgWindow, image=background_photo)
        background_label.place(x=0, y=0, relwidth=1, relheight=1)

        def join_game():

            self.startGame()

        join_game_thread = threading.Thread(target=join_game)
        join_game_thread.start()

        currentTimer = self.servant.getCurrentLobbyTimer();
        timeLeft = tk.Label(self.spgWindow, text=" " + str(currentTimer), font=("Serif", 80, "bold"), fg="#FF66C4")
        timeLeft.place(x=350, y=270)
        timeLeft.config(bg=self.spgWindow["bg"], borderwidth=0)

        if self.timer is not None and self.timer.is_alive():
            self.timer.cancel()

        self.timer = threading.Timer(1, None)

        def timer_sync_thread():
            nonlocal currentTimer

            while currentTimer > 0:
                time.sleep(1)
                currentTimer -= 1
                timeLeft.config(text=str(currentTimer))

        timer_sync_thread = threading.Thread(target=timer_sync_thread)
        timer_sync_thread.start()



        return_button = tk.Button(self.spgWindow, text="Back", font=("Serif", 30, "bold"), fg="#FF66C4",
                                  bg="#DCFB01", command=self.returnButtonClicked)
        return_button.place(x=330, y=420)

        self.spgWindow.mainloop()

    def startGame(self):
        try:
            self.joinedGameObject = self.servant.joinGame(self.usernameTF.get())
        except WordyGame.WordyGameException as ex:
            print(ex.message)
            traceback.print_exc()
            messagebox.showerror("Error", "Error joining the game: " + ex.message)
            return
        self.spgWindow.after(0, self.openGameWindow)

    def returnButtonClicked(self):
        if self.timer is not None and self.timer.is_alive():
            self.timer.cancel()

        self.homeWindow()

    def openGameWindow(self):
        if self.homeWindowInstance and self.homeWindowInstance.winfo_exists():
            self.homeWindowInstance.withdraw()

        self.ogWindow = Toplevel()
        self.ogWindow.title("WORDY GAME")
        self.ogWindow.geometry("715x550")
        self.ogWindow.resizable(False, False)
        self.ogWindow.configure(bg="#0096FF")

        # Create a frame to hold the content
        window_pane = Frame(self.ogWindow, width=480, height=240, bg="white")

        # Create a text widget
        self.text_widget = Text(window_pane, width=480, height=240, bg="white")

        # Add the text widget to the frame
        self.text_widget.grid(row=0, column=0, sticky="nsew")

        # Create a scrollbar widget
        scrollbar = Scrollbar(window_pane, orient="vertical", command=self.text_widget.yview)

        # Configure the text widget to use the scrollbar
        self.text_widget.configure(yscrollcommand=scrollbar.set)

        # Attach the scrollbar to the frame
        scrollbar.grid(row=0, column=1, sticky="ns")

        # Create a label widget
        label = Label(self.ogWindow, text="Use the letters shown below to create a word. Longest Word Wins!",
                      fg="white", font=("serif", 12, "bold"))



        # Place the label widget on top of the canvas
        label.place(relx=0.5, rely=0.03, anchor="n")

        # Remove the background and border of the label
        label.config(bg=self.ogWindow["bg"], borderwidth=0)

        # Create the label widget for the timer text/ winner text
        self.timer_label = Label(self.ogWindow, text="Timer: 10",
                      fg="white", font=("serif", 12, "bold"))

        # Place the label widget on top of the canvas
        self.timer_label.place(relx=0.5, rely=0.08, anchor="n")

        # Remove the background and border of the label
        self.timer_label.config(bg=self.ogWindow["bg"], borderwidth=0)

        # Create the label widget for the random letters
        self.resultLabel = Label(self.ogWindow, text="Timer: 10",
                                 fg="white", font=("serif", 12, "bold"))

        # Place the label widget on top of the canvas
        self.resultLabel.place(relx=0.5, rely=0.11, anchor="n")

        # Remove the background and border of the label
        self.resultLabel.config(bg=self.ogWindow["bg"], borderwidth=0)


        def handle_keypress(event):
            if event.keysym == "Return":
                sendButton.invoke()  # Simulate a button click

        self.wordTF = Entry(self.ogWindow)
        self.wordTF.place(relx =0.2, x=-10, y=450, relwidth=0.5, relheight=0.05)
        self.wordTF.bind("<KeyPress>", handle_keypress)

        sendButton = Button(self.ogWindow, text="Send", command=self.setSendButton, bg="yellow", fg="blue",
                            font=("serif", 10, "bold"))
        sendButton.place(relx=0.1, x=480, y=450, relwidth=0.2, relheight=0.05)

        # Create the LogoutButton
        logoutButton = Button(self.ogWindow, text="LOGOUT", font=("Serif", 15, "bold"), fg="#FF66C4",
                              bg="#DCFB01",command=self.setLogoutButton)
        logoutButton.place(relx =0.1, x=70, y=490, relwidth=0.2, relheight=0.05)

        # Configure grid weights to make the canvas expandable
        window_pane.grid_rowconfigure(0, weight=1)
        window_pane.grid_columnconfigure(0, weight=1)

        # Pack the frame into the window
        window_pane.place(anchor="center", relx=0.5, rely=0.5, relwidth=0.8, relheight=0.6)

        self.ogWindow.bind("<Return>", lambda event: sendButton.invoke())
        self.get_game_data_thread = threading.Thread(target=self.get_game_data)
        self.get_game_data_thread.start()

        self.get_game_data_thread = threading.Thread(target=self.get_game_data)
        self.get_game_data_thread.start()

        self.ogWindow.mainloop()

    def get_game_data(self):
        while not self.joinedGameObject.gameFinished:
            try:
                self.joinedGameObject = self.servant.getGameObject(self.joinedGameObject.gameId)

                try:
                    serverResult = self.servant.obtainCharacters()
                    self.resultLabel.config(text="Round: " + str(self.joinedGameObject.currentRoundNumber) +
                                                 " (Your letters are: " + serverResult + ")")
                except WordyGame.WordyGameException as e:
                    raise RuntimeError(e)

                for player in self.joinedGameObject.players:
                    print(player.username + ": " + str(player.points))

                self.timer_label.config(text="TIMER: " + str(self.joinedGameObject.currentRoundTime))

                # Implement winner handling

                if self.joinedGameObject.gameFinished:
                    messagebox.showinfo("GAME FINISHED WINNER")
                    messagebox.showinfo(self.joinedGameObject.gameWinner + " is the Winner!!")
            except WordyGame.WordyGameException as e:
                print(e)
            time.sleep(0.5)

    #This is to be placed in a loop
    def get_game_data(self):
        while not self.joinedGameObject.gameFinished:
            try:
                self.joinedGameObject = self.servant.getGameObject(self.joinedGameObject.gameId)

                try:
                    serverResult = self.servant.obtainCharacters()
                    self.resultLabel.config(text="Round: " + str(self.joinedGameObject.currentRoundNumber) +
                                                 " (Your letters are: " + serverResult + ")")
                except WordyGame.WordyGameException as e:
                    raise RuntimeError(e)

                for player in self.joinedGameObject.players:
                    print(player.username + ": " + str(player.points))

                self.timer_label.config(text="TIMER: " + str(self.joinedGameObject.currentRoundTime))
                # TODO: Implement winner handling

                if self.joinedGameObject.gameFinished:
                    messagebox.showinfo("GAME FINISHED WINNER")
                    messagebox.showinfo(self.joinedGameObject.gameWinner + " won!!")
            except WordyGame.WordyGameException as e:
                print(e)
            time.sleep(0.5)

    def setLeaderboards(self):
        self.homeWindowInstance.destroy()

        self.leadb = Toplevel()
        self.leadb.title("Leaderboards")
        self.leadb.geometry("715x550")
        self.leadb.resizable(False, False)

        background_image = Image.open("bgleadb.png")
        background_photo = ImageTk.PhotoImage(background_image)
        background_label = tk.Label(self.leadb, image=background_photo)
        background_label.place(x=0, y=0, relwidth=1, relheight=1)

        wordSent = []
        try:
            wordSent = self.servant.getTopWords()
        except WordyGame.WordyGameException as ex:
            print(ex.message)
            traceback.print_exc()

        for word in wordSent:
            longestWord = tk.Label(self.leadb, text="LONGEST WORD", font=("DejaVu Sans Bold", 20, "bold"), fg="magenta")
            longestWord["text"] = "LONGEST WORD: " + word
            longestWord.place(x=110, y=180, width=500, height=40)

        leaderboardLabel = tk.Label(self.leadb, text="TOP PLAYERS", font=("DejaVu Sans Bold", 20, "bold"), fg="magenta")
        leaderboardLabel.place(x=110, y=260, width=500, height=35)

        returnButton = tk.Button(self.leadb, text="Back", font=("Serif", 25, "bold"), fg="#FF66C4", bg="#DCFB01",
                                 command=self.setReturnButton)
        returnButton.place(x=200, y=490, width=300, height=30)

        leadPane = tk.Text(self.leadb, font=("Helvetica", 15), bg="white")
        leadPane.place(x=110, y=300, width=500, height=180)
        leadPane.configure(state="disabled")

        topPlayers = self.servant.getTopPlayers()
        for player in topPlayers:
            leadPane.configure(state="normal")
            leadPane.insert(tk.END, player + "\n")
            leadPane.configure(state="disabled")

    def setReturnButton(self):
        self.leadb.destroy()
        self.homeWindow()
        pass

    def setSendButton(self):
        inputWord = self.wordTF.get()
        userName = self.usernameTF.get()

        try:
            self.servant.sendWord(userName, self.joinedGameObject.gameId, inputWord.lower())
            self.text_widget.insert("end", inputWord + " is valid and is submitted" + "\n")
            self.wordTF.delete(0, "end")
        except WordyGame.WordyGameException as e:
            print(e.message)
            self.text_widget.insert("end" "The word ", inputWord + " is invalid" + "\n")
            self.wordTF.delete(0, "end")


if __name__ == "__main__":
    servant = WordyGame.WordyGameServant()
    gui = GUI_Client(servant)
    gui.mainFrame()
