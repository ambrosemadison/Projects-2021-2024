-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 13, 2023 at 08:40 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tryouts_6c`
--

-- --------------------------------------------------------

--
-- Table structure for table `coordinator`
--

DROP TABLE IF EXISTS `coordinator`;
CREATE TABLE IF NOT EXISTS `coordinator` (
  `coordinatorID` int NOT NULL AUTO_INCREMENT,
  `school` varchar(100) NOT NULL,
  `coordFirstName` varchar(50) NOT NULL,
  `coordMiddleName` varchar(50) NOT NULL,
  `coordLastName` varchar(50) NOT NULL,
  `coordPassword` varchar(8) NOT NULL,
  `coordEmail` varchar(50) NOT NULL,
  `coordContactNumber` varchar(11) NOT NULL,
  PRIMARY KEY (`coordinatorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
CREATE TABLE IF NOT EXISTS `schedule` (
  `scheduleID` int NOT NULL AUTO_INCREMENT,
  `schedDate` date NOT NULL,
  `schedTime` time NOT NULL,
  `location` varchar(30) NOT NULL,
  `sportID` int NOT NULL,
  `coordinatorID` int NOT NULL,
  PRIMARY KEY (`scheduleID`),
  KEY `coordinatorID` (`coordinatorID`),
  KEY `sportID` (`sportID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sport`
--

DROP TABLE IF EXISTS `sport`;
CREATE TABLE IF NOT EXISTS `sport` (
  `sportID` int NOT NULL AUTO_INCREMENT,
  `sportCode` varchar(100) NOT NULL,
  `sportName` varchar(1000) NOT NULL,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`sportID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `studentID` int NOT NULL AUTO_INCREMENT,
  `studFirstName` varchar(50) NOT NULL,
  `studMiddleName` varchar(50) NOT NULL,
  `studLastName` varchar(50) NOT NULL,
  `studPassword` varchar(8) NOT NULL,
  `studEmail` varchar(50) NOT NULL,
  `studContactNumber` varchar(11) NOT NULL,
  PRIMARY KEY (`studentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tryout`
--

DROP TABLE IF EXISTS `tryout`;
CREATE TABLE IF NOT EXISTS `tryout` (
  `tryoutID` int NOT NULL AUTO_INCREMENT,
  `scheduleID` int NOT NULL,
  `studentID` int NOT NULL,
  `result` varchar(50) NOT NULL,
  PRIMARY KEY (`tryoutID`),
  KEY `scheduleID` (`scheduleID`),
  KEY `studentID` (`studentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`coordinatorID`) REFERENCES `coordinator` (`coordinatorID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schedule_ibfk_2` FOREIGN KEY (`sportID`) REFERENCES `sport` (`sportID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tryout`
--
ALTER TABLE `tryout`
  ADD CONSTRAINT `tryout_ibfk_1` FOREIGN KEY (`scheduleID`) REFERENCES `schedule` (`scheduleID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tryout_ibfk_2` FOREIGN KEY (`studentID`) REFERENCES `student` (`studentID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
