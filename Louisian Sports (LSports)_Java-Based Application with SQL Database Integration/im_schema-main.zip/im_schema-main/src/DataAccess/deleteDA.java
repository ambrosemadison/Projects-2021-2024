package DataAccess;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import static DataAccess.dataAccess.connection;

public class deleteDA {
    public static Scanner sc = new Scanner(System.in);

    public static void deleteSchedules() {
        displayDA.displaySchedule();
        try {
            System.out.println("Enter Schedule ID to delete: ");
            int scheduleID = sc.nextInt();

            String deleteQuery = "DELETE FROM schedule WHERE scheduleID = ?";
            PreparedStatement deleteStmt = connection.prepareStatement(deleteQuery);
            deleteStmt.setInt(1, scheduleID);
            int rowsAffected = deleteStmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Schedule Successfully Deleted!");
            } else {
                String checkQuery = "SELECT scheduleID FROM schedule WHERE scheduleID = ?";
                PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
                checkStmt.setInt(1, scheduleID);
                ResultSet resultSet = checkStmt.executeQuery();

                if (resultSet.next()) {
                    System.out.println("Schedule with ID " + scheduleID + " has already been deleted.");
                } else {
                    System.out.println("Schedule with ID " + scheduleID + " does not exist.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Deletion unsuccessful.");
            e.printStackTrace();
        }
    }

    public static void deleteCoordinator() {
        displayDA.displayCoordinator();
        try {
            System.out.println("Enter Coordinator ID to delete: ");
            int coorID = sc.nextInt();
            String query = "DELETE FROM coordinator WHERE coordinatorID = ?";
            PreparedStatement pst = connection.prepareStatement(query);
            pst.setInt(1, coorID);
            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("\n Coordinator Successfully Deleted!");
            } else {
                String checkQuery = "SELECT coordinatorID FROM coordinator WHERE coordinatorID=?";
                PreparedStatement checkSt = connection.prepareStatement(checkQuery);
                checkSt.setInt(1, coorID);
                ResultSet rs = checkSt.executeQuery();
                if (rs.next()){
                    System.out.println("Coordinator with ID " + coorID + " has already been deleted.");
                } else {
                    System.out.println("Coordinator with ID " + coorID + " does not exist.");
                }
            }
        } catch (Exception e) {
            System.out.println("Deletion unsuccessful.");
            e.printStackTrace();
        }
    }

    public static void deleteStudent() {
        displayDA.displayStudents();
        try {
            System.out.println("Enter Student ID to delete: ");
            int studID = sc.nextInt();
            String query = "DELETE FROM student WHERE studentID = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, studID);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Student Successfully Deleted!");
            } else {
                String checkQuery = "SELECT studentID FROM student WHERE studentID =?";
                PreparedStatement checkSt = connection.prepareStatement(checkQuery);
                checkSt.setInt(1, studID);
                ResultSet rs = checkSt.executeQuery();
                if (rs.next()) {
                    System.out.println("Student with ID " + studID + " has already been deleted");
                } else {
                    System.out.println("Student with ID " + studID + " does not exist");
                }
            }
        } catch (SQLException e){
            System.out.println("Deletion unsuccessful.");
            e.printStackTrace();
        }
    }

    public static void deleteTryout() {
        displayDA.displayTryout();
        try {
            System.out.println("Enter Tryout ID to delete: ");
            int tryoutID = sc.nextInt();
            String query = "DELETE FROM tryout WHERE tryoutID = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, tryoutID);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Tryout successfully Deleted!");
            } else {
                String checkQuery = "SELECT tryoutID FROM tryout WHERE tryoutID =?";
                PreparedStatement checkSt = connection.prepareStatement(checkQuery);
                checkSt.setInt(1, tryoutID);
                ResultSet rs = checkSt.executeQuery();
                if (rs.next()) {
                    System.out.println("Tryout with ID " + tryoutID + " has already been deleted");
                } else {
                    System.out.println("Tryout with ID " + tryoutID + " does not exist");
                }
            }
        } catch (SQLException e) {
            System.out.println("Deletion unsuccessful.");
            e.printStackTrace();
        }
    }

    public static void deleteSport() {
        displayDA.displaySport();
        try {
            System.out.println("Enter Sport ID to delete: ");
            int sportID = sc.nextInt();
            String query = "DELETE FROM sport WHERE sportID = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, sportID);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Sport successfully Deleted!");
            } else {
                String checkQuery = "SELECT sportID FROM sport WHERE sportID =?";
                PreparedStatement checkSt = connection.prepareStatement(checkQuery);
                checkSt.setInt(1, sportID);
                ResultSet rs = checkSt.executeQuery();
                if (rs.next()) {
                    System.out.println("Sport with ID " + sportID + " has already been deleted");
                } else {
                    System.out.println("Sport with ID " + sportID + " does not exist");
                }
            }
        } catch (SQLException e) {
            System.out.println("Deletion unsuccessful.");
            e.printStackTrace();
        }
    }
}
