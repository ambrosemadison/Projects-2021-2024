package DataAccess;

import Object.Schedule;
import Object.Tryout;
import Object.Sport;

import java.sql.*;
import java.util.Scanner;

import static DataAccess.dataAccess.retrieveStudentID;
import static DataAccess.displayDA.*;
import static Main.Main.coordID;

public class addDA {
    public static Scanner sc = new Scanner(System.in);

    public static void addSchedules() {
        System.out.println("Enter Date: (ex. 2023-01-17),(Use the year 2023) ");
        Date schedDate = Date.valueOf(sc.next());
        System.out.println("Enter Time: (ex. 11:00:00)");
        Time schedTime = Time.valueOf(sc.next());
        System.out.println("Enter Location: ");
        String location = sc.next();
        displaySport();
        System.out.println("Enter Sport ID:  ");
        int sportID = sc.nextInt();

        Schedule addSchedule;
        try {
            addSchedule = new Schedule(0, schedDate, schedTime, location, sportID, coordID);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        dataAccess.createSchedule(addSchedule);
    }

    public static void addSport() {
        System.out.println("Enter Sport Code: (ex. BB) ");
        String sportCode = sc.next();
        System.out.println("Enter Sport Name: (ex. Basketball) ");
        String sportName = sc.next();
        System.out.println("Enter Category: (Men/Women/All - Case-Sensitive) ");
        String category = sc.next();
        Sport addSport = new Sport(0, sportCode, sportName, category);
        dataAccess.createSport(addSport);
    }

    public static void addTryoutForStudent() {
        displaySchedule();
        System.out.println("Choose Schedule ID: ");
        int tryscheduleID = sc.nextInt();
        System.out.println();

        int studentID = retrieveStudentID(); // Retrieve the student's ID
        if (studentID != 0) {
            Tryout addTryoutForStudent = new Tryout(0, tryscheduleID, studentID, "Pending");
            dataAccess.createTryoutStudents(addTryoutForStudent);
        } else {
            System.out.println("Failed to add tryout. Invalid student ID.");
        }
    }

    // For Retrieving studentID
    public static String getEmail() {
        System.out.println("Enter your email: ");
        return sc.next();
    }
}
