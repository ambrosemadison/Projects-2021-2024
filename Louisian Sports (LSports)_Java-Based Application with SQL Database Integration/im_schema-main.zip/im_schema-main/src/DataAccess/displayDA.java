package DataAccess;

import Object.Coordinator;
import Object.Schedule;
import Object.Student;
import Object.Tryout;

import java.sql.SQLException;
import java.util.List;

import static DataAccess.dataAccess.*;
import static Main.Main.coordID;
import static Main.Main.studentID;

public class displayDA {

    public static void displaySpecificCoordinatorDetails(){
        try {
            Coordinator specCoordinator = getCoordinatorByID(coordID);
            if (specCoordinator != null) {
                System.out.printf("%20s %20s %20s %20s %20s %20s %25s %25s %n", "Coordinator ID", "School", "First Name", "Middle Name", "Last Name", "Password", "Email", "Contact Number");
                System.out.printf("%20s %20s %20s %20s %20s %20s %25s %25s %n", specCoordinator.getCoordinatorID(), specCoordinator.getSchool(), specCoordinator.getCoordFirstName(),
                        specCoordinator.getCoordMiddleName(), specCoordinator.getCoordLastName(), specCoordinator.getCoordPassword(), specCoordinator.getCoordEmail(), specCoordinator.getCoordContactNumber());
            } else {
                System.out.println("Coordinator not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error occurred while retrieving coordinator: " + e.getMessage());
        }
    }

    public static void displaySpecificStudentDetails(){
        try {
            Student specStudent = getStudentsByCode(studentID);
            if (specStudent != null) {
                System.out.printf("%20s %20s %20s %20s %20s %25s %25s %n", "Student ID", "First Name", "Middle Name", "Last Name", "Password", "Email", "Contact Number");
                System.out.printf("%20s %20s %20s %20s %20s %25s %25s %n", specStudent.getStudentID(), specStudent.getStudFirstName(), specStudent.getStudMiddleName(),
                        specStudent.getStudLastName(), specStudent.getStudPassword(), specStudent.getStudEmail(), specStudent.getStudContactNumber());
            } else {
                System.out.println("Student not found.");
            }
        } catch (Exception e) {
            System.out.println("Error occurred while retrieving student: " + e.getMessage());
        }
    }

    public static void displaySchedSpecificToCoordinator(){
        try {
            Schedule specSchedCoordinator = getScheduleByID(coordID);
            if (specSchedCoordinator != null){
                System.out.printf("%20s %20s %20s %20s %20s %20s %20s %25s %27s %20s %n", "Schedule ID", "Date", "Time",
                        "Location","SportID", "Sport Name", "Category", "CoordinatorID", "Coordinator Last Name", "School");
                System.out.printf("%20s %20s %20s %20s %20s %20s %20s %25s %27s %20s %n", specSchedCoordinator.getScheduleID(),
                        specSchedCoordinator.getSchedDate(), specSchedCoordinator.getSchedTime(), specSchedCoordinator.getLocation(),
                        specSchedCoordinator.getSportID(), specSchedCoordinator.getSportName(), specSchedCoordinator.getCategory(),
                        specSchedCoordinator.getCoordinatorID(), specSchedCoordinator.getCoordinatorLastName(), specSchedCoordinator.getSchool());
            } else {
                System.out.println("Coordinator not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void displaySpecificTryout(){
        try {
            Tryout specTryout = getTryoutsByID(studentID);
            if (specTryout != null) {
                System.out.printf("%-15s %-15s %-15s %-15s %-20s %-15s %-5s %15s %15s %n",
                        "Tryout ID", "Schedule Date", "Schedule Time", "Location", "Student ID", "Student Name", "Sport Name", "Category", "Result");
                System.out.printf("%-15s %-15s %-15s %-15s %-20s %-7s %-5s %12s %13s %17s %n", specTryout.getTryoutID(), specTryout.getSchedDate(), specTryout.getSchedTime(),
                        specTryout.getLocation(), specTryout.getStudentID(), specTryout.getStudFirstname(), specTryout.getStudLastName(),
                        specTryout.getSportName(), specTryout.getCategory(), specTryout.getResult());
            } else {
                System.out.println("Student not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void displayAllTryoutsSpecificToCoordinator() {
        try {
            List<Tryout> tryouts = getTryoutsByCoordinatorID(coordID);
            if (!tryouts.isEmpty()) {
                System.out.printf("%-15s %-15s %-15s %-15s %-20s %-15s %-5s %15s %15s %n",
                        "Tryout ID", "Schedule Date", "Schedule Time", "Location", "Student ID", "Student Name", "Sport Name", "Category", "Result");
                for (Tryout tryout : tryouts) {
                    System.out.printf("%-15s %-15s %-15s %-15s %-20s %-7s %-5s %12s %13s %17s %n",
                            tryout.getTryoutID(), tryout.getSchedDate(), tryout.getSchedTime(),
                            tryout.getLocation(), tryout.getStudentID(), tryout.getStudFirstname(),
                            tryout.getStudLastName(), tryout.getSportName(), tryout.getCategory(),
                            tryout.getResult());
                }
            } else {
                System.out.println("Tryout not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void displayTryout() {
        System.out.printf("%-15s %-15s %-15s %-15s %-20s %-15s %-10s %n",
                "Tryout ID", "Schedule ID", "Schedule Date", "Schedule Time", "Location", "Student ID", "Result");
        dataAccess.getAllTryouts();
        System.out.println();
    }

    public static void displaySchedule() {
        System.out.printf("%20s %20s %20s %20s %20s %20s %20s %25s %27s %20s %n", "Schedule ID", "Date", "Time",
                "Location","SportID", "Sport Name", "Category", "CoordinatorID", "Coordinator", "School");
        dataAccess.getAllSchedules();
        System.out.println();
    }

    public static void displayCoordinator(){
        System.out.printf("%20s %20s %20s %20s %25s %25s %n", "Coordinator ID", "School", "First Name", "Last Name", "Email", "Contact Number");
        dataAccess.getAllCoordinators();
        System.out.println();
    }

    public static void displayStudents(){
        System.out.printf("%20s %20s %20s %20s %25s %25s %n", "Student ID", "First Name", "Middle Name", "Last Name", "Email", "Contact Number");
        dataAccess.getAllStudents();
        System.out.println();
    }

    public static void displaySport(){
        System.out.printf("%s %20s %20s %20s %n", "Sport ID", "Sport Code", "Sport Name", "Category");
        dataAccess.getAllSports();
        System.out.println();

    }
}


