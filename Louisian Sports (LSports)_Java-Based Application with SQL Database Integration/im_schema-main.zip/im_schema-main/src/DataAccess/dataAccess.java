package DataAccess;

import Object.Coordinator;
import Object.Student;
import Object.Schedule;
import Object.Tryout;
import Object.Sport;
import Main.Main;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static DataAccess.addDA.getEmail;

public class dataAccess {
    public static Connection connection;

    public static void setConnection() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3308/6C?user=root&password");
            System.out.println("SQL Database Connected.");
        } catch (Exception e) {
            System.out.println("Database Connection Failed.");
            e.printStackTrace();
        }
    }

    public static List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT studentID, studFirstName, studMiddleName, studLastName, studEmail, studContactNumber FROM STUDENT");
            while (rs.next()) {
                Student s = new Student();
                s.setStudentID(rs.getInt("studentID"));
                s.setStudFirstName(rs.getString("studFirstName"));
                s.setStudMiddleName(rs.getString("studMiddleName"));
                s.setStudLastName(rs.getString("studLastName"));
                s.setStudEmail(rs.getString("studEmail"));
                s.setStudContactNumber(rs.getString("studContactNumber"));
                students.add(s);
                System.out.format("%20s %20s %20s %20s %25s %25s %n", s.getStudentID(), s.getStudFirstName(),
                        s.getStudMiddleName(), s.getStudLastName(), s.getStudEmail(), s.getStudContactNumber());
            }
            rs.close();
            stmt.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return students;
    }

    public static void createStudent(Student s) {
        String query = "SELECT * FROM STUDENT WHERE studFirstName = ? AND studMiddleName = ? AND studLastName = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, s.getStudFirstName());
            statement.setString(2, s.getStudMiddleName());
            statement.setString(3, s.getStudLastName());
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Student already exists.");
            } else {
                query = "SELECT * FROM STUDENT WHERE studEmail = ?";
                statement = connection.prepareStatement(query);
                statement.setString(1, s.getStudEmail());
                resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    System.out.println("Email already exists.");
                } else {
                    PreparedStatement stmnt = connection.prepareStatement(
                            "INSERT INTO STUDENT (studFirstName, studMiddleName, studLastName, studPassword, studEmail, studContactNumber) " +
                                    "VALUES (?, ?, ?, ?, ?, ?)");
                    stmnt.setString(1, s.getStudFirstName());
                    stmnt.setString(2, s.getStudMiddleName());
                    stmnt.setString(3, s.getStudLastName());
                    stmnt.setString(4, s.getStudPassword());
                    stmnt.setString(5, s.getStudEmail());
                    stmnt.setString(6, s.getStudContactNumber());
                    stmnt.executeUpdate();
                    System.out.println("New Student Registered.");
                    System.out.println("---------------------------------------\n");
                    Main.menu();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Student getStudentsByCode(int studentID) throws SQLException {
        String query = "SELECT * FROM STUDENT WHERE studentID=?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, studentID);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            return new Student(
                    resultSet.getInt("studentID"),
                    resultSet.getString("studFirstName"),
                    resultSet.getString("studMiddleName"),
                    resultSet.getString("studLastName"),
                    resultSet.getString("studPassword"),
                    resultSet.getString("studEmail"),
                    resultSet.getString("studContactNumber")
            );
        }
        return null;
    }

    public static void updateStudent(Student s) {
        String query = "UPDATE STUDENT SET studFirstName = ?, studMiddleName = ?, studLastName = ?, studPassword = ?, studEmail = ?, studContactNumber = ? WHERE studentID = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, s.getStudFirstName());
            statement.setString(2, s.getStudMiddleName());
            statement.setString(3, s.getStudLastName());
            statement.setString(4, s.getStudPassword());
            statement.setString(5, s.getStudEmail());
            statement.setString(6, s.getStudContactNumber());
            statement.setInt(7, s.getStudentID());
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Student updated successfully.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Student> findStudentbyStudID(Integer studentID) {
        Student s;
        ArrayList<Student> students = new ArrayList<>();
        String query = "SELECT * FROM student WHERE studentID LIKE ? ORDER BY studentID";
        try {
            PreparedStatement ps = connection.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ps.setInt(1, studentID);
            ResultSet rs = ps.executeQuery();
            rs.beforeFirst();
            while (rs.next()) {
                s = new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
                        rs.getString(6), rs.getString(7));
                students.add(s);
                System.out.println("Student found.");
            }
        } catch (SQLException e) {
            System.out.println("Could not find Student.");
        }
        return students;
    }

    public static List<Coordinator> getAllCoordinators() {
        List<Coordinator> coordinators = new ArrayList<>();
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT coordinatorID, school, coordFirstName, coordLastName, coordEmail, coordContactNumber FROM COORDINATOR");
            while (rs.next()) {
                Coordinator coordinator = new Coordinator();
                coordinator.setCoordinatorID(rs.getInt("coordinatorID"));
                coordinator.setSchool(rs.getString("school"));
                coordinator.setCoordFirstName(rs.getString("coordFirstName"));
                coordinator.setCoordLastName(rs.getString("coordLastName"));
                coordinator.setCoordEmail(rs.getString("coordEmail"));
                coordinator.setCoordContactNumber(rs.getString("coordContactNumber"));
                coordinators.add(coordinator);
                System.out.format("%20s %20s %20s %20s %25s %25s %n", coordinator.getCoordinatorID(), coordinator.getSchool(), coordinator.getCoordFirstName(),
                        coordinator.getCoordLastName(), coordinator.getCoordEmail(), coordinator.getCoordContactNumber());
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return coordinators;
    }

    public static Coordinator getCoordinatorByID(int coordinatorID) throws SQLException {
        String query = "SELECT * FROM COORDINATOR WHERE coordinatorID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, coordinatorID);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            return new Coordinator(
                    resultSet.getInt("coordinatorID"),
                    resultSet.getString("school"),
                    resultSet.getString("coordFirstName"),
                    resultSet.getString("coordMiddleName"),
                    resultSet.getString("coordLastName"),
                    resultSet.getString("coordPassword"),
                    resultSet.getString("coordEmail"),
                    resultSet.getString("coordContactNumber")
            );
        }
        return null;
    }

    public static void createCoordinator(Coordinator coordinator) throws Exception {
        String query = "SELECT * FROM COORDINATOR WHERE coordFirstName = ? AND coordMiddleName = ? AND coordLastName = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, coordinator.getCoordFirstName());
            statement.setString(2, coordinator.getCoordMiddleName());
            statement.setString(3, coordinator.getCoordLastName());
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                System.out.println("Coordinator already exists.");
            } else {
                query = "SELECT * FROM COORDINATOR WHERE school = ?";
                statement = connection.prepareStatement(query);
                statement.setString(1, coordinator.getSchool());
                rs = statement.executeQuery();
                if (rs.next()) {
                    System.out.println("School already exists and already has a Coordinator.");
                } else {
                    String[] validSchools = {"SEA", "SAMCIS", "SOL", "SOM", "SONAHBS", "STELA", "SAS"};
                    boolean valid = false;
                    for (String school : validSchools) {
                        if (coordinator.getSchool().equalsIgnoreCase(school)) {
                            valid = true;
                            break;
                        }
                    }
                    if (!valid) {
                        System.out.println("Invalid school.");
                    } else {
                        query = "SELECT * FROM COORDINATOR WHERE coordEmail = ?";
                        statement = connection.prepareStatement(query);
                        statement.setString(1, coordinator.getCoordEmail());
                        rs = statement.executeQuery();
                        if (rs.next()) {
                            System.out.println("Email already exists.");
                        } else {
                            // Additional validation for names
                            query = "SELECT * FROM COORDINATOR WHERE (coordFirstName = ? OR coordMiddleName = ? OR coordLastName = ?)";
                            statement = connection.prepareStatement(query);
                            statement.setString(1, coordinator.getCoordFirstName());
                            statement.setString(2, coordinator.getCoordMiddleName());
                            statement.setString(3, coordinator.getCoordLastName());
                            rs = statement.executeQuery();
                            if (rs.next()) {
                                System.out.println("A similar name already exists.");
                            } else {
                                query = "INSERT INTO COORDINATOR (school, coordFirstName, coordMiddleName, coordLastName, coordPassword, coordEmail, coordContactNumber) " +
                                        "VALUES (?, ?, ?, ?, ?, ?, ?)";
                                statement = connection.prepareStatement(query);
                                statement.setString(1, coordinator.getSchool());
                                statement.setString(2, coordinator.getCoordFirstName());
                                statement.setString(3, coordinator.getCoordMiddleName());
                                statement.setString(4, coordinator.getCoordLastName());
                                statement.setString(5, coordinator.getCoordPassword());
                                statement.setString(6, coordinator.getCoordEmail());
                                statement.setString(7, coordinator.getCoordContactNumber());
                                int rowsInserted = statement.executeUpdate();
                                if (rowsInserted > 0) {
                                    System.out.println("New Coordinator Registered");
                                    System.out.println("---------------------------------------\n");
                                    Main.menu();
                                }
                            }
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateCoordinator(Coordinator coordinator) {
        String query = "UPDATE COORDINATOR SET coordPassword = ?, coordContactNumber = ? WHERE coordinatorID = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, coordinator.getCoordPassword());
            statement.setString(2, coordinator.getCoordContactNumber());
            statement.setInt(3, coordinator.getCoordinatorID());
            statement.executeUpdate();
            System.out.println("Coordinator updated successfully");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to update Coordinator.");
        }
    }

    public static ArrayList<Coordinator> findCoordinatorByCoorID(Integer coordinatorID) {
        Coordinator c;
        ArrayList<Coordinator> coordinators = new ArrayList<>();
        String query = "SELECT * FROM coordinator WHERE coordinatorID LIKE ? ORDER BY coordinatorID";
        try {
            PreparedStatement ps = connection.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ps.setInt(1, coordinatorID);
            ResultSet rs = ps.executeQuery();
            rs.beforeFirst();
            while (rs.next()) {
                c = new Coordinator(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
                        rs.getString(6), rs.getString(7), rs.getString(8));
                coordinators.add(c);
                System.out.println("Coordinator found.");
            }
        } catch (SQLException e) {
            System.out.println("Could not find Coordinator.");
        }
        return coordinators;
    }

    public static List<Schedule> getAllSchedules() {
        List<Schedule> schedules = new ArrayList<>();
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT s.*, sp.sportName, sp.category, c.coordFirstName, c.coordLastName, " +
                    "c.school FROM SCHEDULE s JOIN sport sp ON s.sportID = sp.sportID JOIN coordinator c ON s.coordinatorID = c.coordinatorID");
            while (rs.next()) {
                Schedule schedule = new Schedule();
                schedule.setScheduleID(rs.getInt("scheduleID"));
                schedule.setSchedDate(rs.getDate("schedDate"));
                schedule.setSchedTime(rs.getTime("schedTime"));
                schedule.setLocation(rs.getString("location"));
                schedule.setSportID(rs.getInt("sportID"));
                schedule.setSportName(rs.getString("sportName"));
                schedule.setCategory(rs.getString("category"));
                schedule.setCoordinatorID(rs.getInt("coordinatorID"));
                schedule.setCoordinatorFirstName(rs.getString("coordFirstName"));
                schedule.setCoordinatorLastName(rs.getString("coordLastName"));
                schedule.setSchool(rs.getString("school"));
                schedules.add(schedule);
                System.out.format("%20s %20s %20s %20s %20s %20s %20s %25s %20s %4s %20s %n", schedule.getScheduleID(), schedule.getSchedDate(),
                        schedule.getSchedTime(), schedule.getLocation(), schedule.getSportID(), schedule.getSportName(),
                        schedule.getCategory(), schedule.getCoordinatorID(), schedule.getCoordinatorFirstName(), schedule.getCoordinatorLastName(), schedule.getSchool());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return schedules;
    }

    public static Schedule getScheduleByID(int scheduleID) throws SQLException {
        String query = "SELECT s.*, sp.sportName, sp.category, c.coordFirstName, c.coordLastName, c.school " +
                "FROM SCHEDULE s " +
                "JOIN sport sp ON s.sportID = sp.sportID " +
                "JOIN coordinator c ON s.coordinatorID = c.coordinatorID " +
                "WHERE scheduleID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, scheduleID);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            return new Schedule(
                    resultSet.getInt("scheduleID"),
                    resultSet.getDate("schedDate"),
                    resultSet.getTime("schedTime"),
                    resultSet.getString("location"),
                    resultSet.getInt("sportID"),
                    resultSet.getString("sportName"),
                    resultSet.getString("category"),
                    resultSet.getInt("coordinatorID"),
                    resultSet.getString("coordFirstName"),
                    resultSet.getString("coordLastName"),
                    resultSet.getString("school")
            );
        }
        return null;
    }

    public static void createSchedule(Schedule schedule) {
        String query = "SELECT * FROM SCHEDULE WHERE schedDate = ? AND schedTime = ? AND location = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setDate(1, schedule.getSchedDate());
            statement.setTime(2, schedule.getSchedTime());
            statement.setString(3, schedule.getLocation());
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("\n *** Schedule is already taken. ***");
            }else {
                // Validation for date
                // If date has already passed then schedule would not be added
                LocalDate currentDate = LocalDate.now();
                LocalDate inputDate = schedule.getSchedDate().toLocalDate();
                if (inputDate.isBefore(currentDate)){
                    System.out.println("\n *** Date has already passed. Try another date. ***");
                }
                else {
                    PreparedStatement pstmt = connection.prepareStatement("INSERT INTO SCHEDULE (schedDate, schedTime, location, sportID, coordinatorID) VALUES (?, ?, ?, ?, ?)");
                    pstmt.setDate(1, new java.sql.Date(schedule.getSchedDate().getTime()));
                    pstmt.setTime(2, schedule.getSchedTime());
                    pstmt.setString(3, schedule.getLocation());
                    pstmt.setInt(4, schedule.getSportID());
                    pstmt.setInt(5, schedule.getCoordinatorID());
                    pstmt.executeUpdate();
                    System.out.println("Schedule Successfully Created.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Failed to create Schedule.");
            e.printStackTrace();
        }
    }

    public static void updateSchedule(Schedule schedule) {
        try {
            PreparedStatement pstmt = connection.prepareStatement("UPDATE SCHEDULE SET schedDate=?, schedTime=?, location=?,  sportID=?, coordinatorID=? WHERE scheduleID=?");
            pstmt.setDate(1, new java.sql.Date(schedule.getSchedDate().getTime()));
            pstmt.setTime(2, schedule.getSchedTime());
            pstmt.setString(3, schedule.getLocation());
            pstmt.setInt(4, schedule.getSportID());
            pstmt.setInt(5, schedule.getCoordinatorID());
            pstmt.setInt(6, schedule.getScheduleID());
            pstmt.executeUpdate();
            System.out.println("Schedule updated successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to update Schedule.");
        }
    }

    public static ArrayList<Schedule> findSchedulesByScheduleID(Integer scheduleID) {
        Schedule schedule;
        ArrayList<Schedule> schedules = new ArrayList<>();
        String query = "SELECT s.*, sp.sportName, sp.category, c.coordFirstName, c.coordLastName, c.school " +
                "FROM schedule s " +
                "JOIN sport sp ON s.sportID = sp.sportID " +
                "JOIN coordinator c ON s.coordinatorID = c.coordinatorID " +
                "WHERE s.scheduleID LIKE ? " +
                "ORDER BY s.scheduleID";
        try {
            PreparedStatement pstmt = connection.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            pstmt.setInt(1, scheduleID);
            ResultSet rs = pstmt.executeQuery();
            rs.beforeFirst();
            while (rs.next()) {
                schedule = new Schedule(
                        rs.getInt("scheduleID"),
                        rs.getDate("schedDate"),
                        rs.getTime("schedTime"),
                        rs.getString("location"),
                        rs.getInt("sportID"),
                        rs.getString("sportName"),
                        rs.getString("category"),
                        rs.getInt("coordinatorID"),
                        rs.getString("coordFirstName"),
                        rs.getString("coordLastName"),
                        rs.getString("school")
                );
                schedules.add(schedule);
            }
            System.out.println("Schedule Found.");
        } catch (SQLException e) {
            System.out.println("Could not find Schedule.");
        }
        return schedules;
    }

    public static List<Tryout> getAllTryouts() {
        List<Tryout> tryouts = new ArrayList<>();
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT t.tryoutID, t.scheduleID, t.studentID, t.result, s.schedDate, s.schedTime, s.location " +
                    "FROM tryout t " +
                    "JOIN schedule s ON t.scheduleID = s.scheduleID");
            while (rs.next()) {
                Tryout tryout = new Tryout();
                tryout.setTryoutID(rs.getInt("tryoutID"));
                tryout.setScheduleID(rs.getInt("scheduleID"));
                tryout.setStudentID(rs.getInt("studentID"));
                tryout.setResult(rs.getString("result"));
                System.out.printf("%-15s %-15s %-15s %-15s %-20s %-15s %-10s %n",
                        tryout.getTryoutID(), tryout.getScheduleID(), rs.getDate("schedDate"),
                        rs.getTime("schedTime"), rs.getString("location"), tryout.getStudentID(), tryout.getResult());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tryouts;
    }

    public static Tryout getTryoutsByID(int tryoutID) throws SQLException {
        String query = "SELECT t.tryoutID,s.schedDate, s.schedTime, s.location,t.studentID, st.studLastName,st.studFirstName, sp.sportName, sp.category, t.result FROM tryout t JOIN schedule s ON t.scheduleID = s.scheduleID JOIN student st ON t.studentID = st.studentID JOIN sport sp ON s.sportID = sp.sportID WHERE t.studentID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, tryoutID);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            return new Tryout(
                    resultSet.getInt("tryoutID"),
                    resultSet.getDate("schedDate"),
                    resultSet.getTime("schedTime"),
                    resultSet.getString("location"),
                    resultSet.getInt("studentID"),
                    resultSet.getString("studLastName"),
                    resultSet.getString("studFirstName"),
                    resultSet.getString("sportName"),
                    resultSet.getString("category"),
                    resultSet.getString("result")
            );
        }
        return null;
    }

    public static List<Tryout> getTryoutsByCoordinatorID(int coordinatorID) throws SQLException {
        List<Tryout> tryouts = new ArrayList<>();
        String query = "SELECT t.tryoutID, s.schedDate, s.schedTime, s.location, t.studentID, " +
                "st.studLastName, st.studFirstName, sp.sportName, sp.category, t.result " +
                "FROM tryout t " +
                "JOIN schedule s ON t.scheduleID = s.scheduleID " +
                "JOIN student st ON t.studentID = st.studentID " +
                "JOIN sport sp ON s.sportID = sp.sportID " +
                "WHERE s.coordinatorID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, coordinatorID);
        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            Tryout tryout = new Tryout(
                    resultSet.getInt("tryoutID"),
                    resultSet.getDate("schedDate"),
                    resultSet.getTime("schedTime"),
                    resultSet.getString("location"),
                    resultSet.getInt("studentID"),
                    resultSet.getString("studLastName"),
                    resultSet.getString("studFirstName"),
                    resultSet.getString("sportName"),
                    resultSet.getString("category"),
                    resultSet.getString("result")
            );
            tryouts.add(tryout);
        }
        return tryouts;
    }

    public static void createTryoutStudents(Tryout tryout) {
        try {
            PreparedStatement insertStmt = connection.prepareStatement("INSERT INTO TRYOUT (scheduleID, studentID, result) VALUES (?, ?, ?)");
            insertStmt.setInt(1, tryout.getScheduleID());
            insertStmt.setInt(2, tryout.getStudentID());
            insertStmt.setString(3, tryout.getResult());
            insertStmt.executeUpdate();
            System.out.println("New tryout created.");
        } catch (SQLException e) {
            System.out.println("Failed to create a Tryout");
            e.printStackTrace();
        }
    }

    public static int retrieveStudentID() {
        String email = getEmail(); // Implement the logic to obtain the email
        try {
            PreparedStatement selectStmt = connection.prepareStatement("SELECT studentID FROM student WHERE studEmail = ?");
            selectStmt.setString(1, email);
            ResultSet resultSet = selectStmt.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("studentID");
            } else {
                // Handle the case when the email is not found
                System.out.println("Email not found.");
                return 0; // or any appropriate default value
            }
        } catch (SQLException e) {
            System.out.println("Failed to retrieve the student ID");
            e.printStackTrace();
            return 0; // or any appropriate default value
        }
    }

    public static void updateTryout(Tryout tryout) {
        try {
            String query = "UPDATE TRYOUT SET result=? WHERE tryoutID=?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, tryout.getResult());
            pstmt.setInt(2, tryout.getTryoutID());
            pstmt.executeUpdate();
            System.out.println("Tryout updated successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to update Tryout.");
            e.printStackTrace();
        }
    }

    public static boolean checkTryouts (int coordinatorID) throws SQLException {
        String query = "SELECT COUNT(*) FROM schedule JOIN tryout ON schedule.scheduleID = tryout.scheduleID WHERE schedule.coordinatorID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, coordinatorID);
        ResultSet resultSet = statement.executeQuery();
        resultSet.next();
        int tryoutCount = resultSet.getInt(1);
        return tryoutCount > 0;
    }

    public static int getTryoutByCoordinatorID(int tryoutID) throws SQLException {
        String query = "SELECT coordinatorID FROM schedule JOIN tryout ON schedule.scheduleID = tryout.scheduleID WHERE tryout.tryoutID = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setInt(1, tryoutID);
        ResultSet rs = stmt.executeQuery();
        int coordinatorID = 0;
        if (rs.next()) {
            coordinatorID = rs.getInt("coordinatorID");
        }
        return coordinatorID;
    }

    public static List<Sport> getAllSports() {
        List<Sport> sports = new ArrayList<>();
        try {
            String query = "SELECT * FROM SPORT";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Sport sport = new Sport();
                sport.setSportID(rs.getInt("sportID"));
                sport.setSportCode(rs.getString("sportCode"));
                sport.setSportName(rs.getString("sportName"));
                sport.setCategory(rs.getString("category"));
                sports.add(sport);
                System.out.format("%s %27s %20s %20s %n", sport.getSportID(), sport.getSportCode(), sport.getSportName(), sport.getCategory());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sports;
    }

    public static void updateSport(Sport sport) {
        try {
            String query = "UPDATE SPORT SET sportCode = ?, sportName = ?, category = ? WHERE sportID = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, sport.getSportCode());
            pstmt.setString(2, sport.getSportName());
            pstmt.setString(3, sport.getCategory());
            pstmt.setInt(4, sport.getSportID());
            pstmt.executeUpdate();
            System.out.println("Sport successfully updated.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Sport getSportByID(int sportID) throws SQLException {
        String query = "SELECT * FROM SPORT where sportID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, sportID);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            return new Sport(
                    resultSet.getInt("sportID"),
                    resultSet.getString("sportCode"),
                    resultSet.getString("sportName"),
                    resultSet.getString("category")
            );
        }
        return null;
    }

    public static void createSport(Sport sports) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM SPORT WHERE sportCode=? AND sportName=? AND category=?");
            statement.setString(1, sports.getSportCode());
            statement.setString(2, sports.getSportName());
            statement.setString(3, sports.getCategory());
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                // record already exists, do not insert
                System.out.println("Sport already exists.");
            } else {
                String category = sports.getCategory();
                if (category.equals("All") || category.equals("Women") || category.equals("Men")) {
                    String query = "INSERT INTO SPORT (sportCode, sportName, category) VALUES (?, ?, ?)";
                    PreparedStatement pstmt = connection.prepareStatement(query);
                    pstmt.setString(1, sports.getSportCode());
                    pstmt.setString(2, sports.getSportName());
                    pstmt.setString(3, category);
                    pstmt.executeUpdate();
                    System.out.println();
                    System.out.println("New sport created.");
                } else {
                    System.out.println("Invalid category. Only 'All', 'Women', and 'Men' are allowed. - Case-Sensitive ");
                }
            }
        } catch (SQLException e) {
            System.out.println("Failed to create Sport.");
            e.printStackTrace();
        }
    }

    public static ArrayList<Sport> findSportBySportID(int sportID) {
        Sport sport;
        ArrayList<Sport> sports = new ArrayList<>();
        String query = "SELECT * FROM sport WHERE sportID LIKE ? ORDER BY sportID";
        try {
            PreparedStatement ps = connection.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ps.setInt(1, sportID);
            ResultSet rs = ps.executeQuery();
            rs.beforeFirst();
            while (rs.next()) {
                sport = new Sport(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
                sports.add(sport);
                System.out.println("Sport found.");
            }
        } catch (SQLException e) {
            System.out.println("Could not find Sport.");
        }
        return sports;
    }
}
