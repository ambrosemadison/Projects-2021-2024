package DataAccess;

import java.util.Scanner;
import Object.Schedule;
import Object.Student;
import Object.Coordinator;
import Object.Sport;

import java.util.ArrayList;

public class searchDA {
    public static Scanner sc = new Scanner(System.in);
    public static ArrayList<Schedule> scheduleArrayList = new ArrayList<>();
    public static ArrayList<Student> studentArrayList = new ArrayList<>();
    public static ArrayList<Coordinator> coordinatorArrayList = new ArrayList<>();
    public static ArrayList<Sport> sportsArrayList = new ArrayList<>();

    public static void searchSchedulesByScheduleID() {
        System.out.println("Enter Schedule ID: ");
        int searchScheduleID = sc.nextInt();
        scheduleArrayList.clear();
        scheduleArrayList = dataAccess.findSchedulesByScheduleID(searchScheduleID);
        for (Schedule schedule : scheduleArrayList) {
            System.out.printf("%20s %20s %20s %20s %20s %20s %20s %25s %27s %20s %n", "Schedule ID", "Date", "Time",
                    "Location","SportID", "Sport Name", "Category", "CoordinatorID", "Coordinator", "School");
            System.out.format("%20s %20s %20s %20s %20s %20s %20s %25s %20s %4s %20s %n", schedule.getScheduleID(), schedule.getSchedDate(),
                    schedule.getSchedTime(), schedule.getLocation(), schedule.getSportID(), schedule.getSportName(),
                    schedule.getCategory(), schedule.getCoordinatorID(), schedule.getCoordinatorFirstName(), schedule.getCoordinatorLastName(), schedule.getSchool());
        }
        if (scheduleArrayList.isEmpty()) {
            System.out.println("Schedule not found.");
        }
    }

    public static void searchStudentsByStudentID() {
        System.out.println("Enter Student ID: ");
        int searchStudID = sc.nextInt();
        studentArrayList.clear();
        studentArrayList = dataAccess.findStudentbyStudID(searchStudID);
        for (Student s : studentArrayList) {
            System.out.printf("%-20s %-20s %-20s %-20s %-35s %-25s %n", "Student ID", "First Name", "Middle Name", "Last Name", "Email", "Contact Number");
            System.out.printf("%-20s %-20s %-20s %-20s %-35s %-25s  \n", s.getStudentID(),
                    s.getStudFirstName(), s.getStudMiddleName(), s.getStudLastName(), s.getStudEmail(), s.getStudContactNumber());
        }
        if (studentArrayList.isEmpty()) {
            System.out.println("Student not found.");
        }
    }

    public static void searchCoordinatorByCoordinatorID() {
        System.out.println("Enter Coordinator ID: ");
        int searchCoorID = sc.nextInt();
        coordinatorArrayList.clear();
        coordinatorArrayList = dataAccess.findCoordinatorByCoorID(searchCoorID);
        for (Coordinator c : coordinatorArrayList) {
            System.out.printf("%20s %20s %20s %20s %25s %20s %n", "Coordinator ID", "School", "First Name", "Last Name", "Email", "Contact Number");
            System.out.printf("%20s %20s %20s %20s %25s %20s \n", c.getCoordinatorID(), c.getSchool(), c.getCoordFirstName(), c.getCoordLastName(), c.getCoordEmail(), c.getCoordContactNumber());
        }
        if (coordinatorArrayList.isEmpty()) {
            System.out.println("Coordinator not found.");
        }

    }

    public static void searchSportBySportID() {
        System.out.println("Enter Sport ID: ");
        int sportID = sc.nextInt();
        sportsArrayList.clear();
        sportsArrayList = dataAccess.findSportBySportID(sportID);
        for (Sport sport : sportsArrayList) {
            System.out.printf("%s %20s %20s %20s  %n", "Sport ID", "Sport Code", "Sport Name", "Category");
            System.out.printf("%s %27s %20s %20s  %n \n", sport.getSportID(), sport.getSportCode(),
                    sport.getSportName(), sport.getCategory());
        }
        if (sportsArrayList.isEmpty()) {
            System.out.println("Sport not found.");
        }
    }
}


