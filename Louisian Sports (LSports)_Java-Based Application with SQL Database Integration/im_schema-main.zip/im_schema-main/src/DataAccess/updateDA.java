package DataAccess;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Scanner;

import Object.Schedule;
import Object.Coordinator;
import Object.Student;
import Object.Tryout;
import Object.Sport;

import static Main.Main.*;

public class updateDA {
    public static Scanner sc = new Scanner(System.in);

    public static void updateCoordinator() throws SQLException {
        displayDA.displaySpecificCoordinatorDetails();
        Coordinator coordinator = dataAccess.getCoordinatorByID(coordID);
        if (coordinator == null) {
            System.out.println("Coordinator not found.");
        }
        System.out.println("What do you want to update?");
        System.out.println("1. Change Password");
        System.out.println("2. Update Contact Number");
        System.out.println("3. Return to Menu");
        System.out.println("Enter your choice: ");
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Enter New Password: (Password must be 8 characters) ");
                String updateCoorPassword = sc.next();
                assert coordinator != null;
                coordinator.setCoordPassword(updateCoorPassword);
                break;
            case 2:
                System.out.println("Enter New Contact Number: (Please enter 11 numbers) ");
                String updateCoorConNum = sc.next();
                assert coordinator != null;
                coordinator.setCoordContactNumber(updateCoorConNum);
                break;
            case 3:
                try {
                    coordinator();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
        assert coordinator != null;
        dataAccess.updateCoordinator(coordinator);
        System.out.println("Updated Details");
        displayDA.displaySpecificCoordinatorDetails();
    }

    public static void updateSchedule() throws SQLException {
        displayDA.displaySchedSpecificToCoordinator();
        Schedule schedule = dataAccess.getScheduleByID(coordID);
        if (schedule == null) {
            System.out.println("Schedule not found.");
            return;
        }
        System.out.println("What do you want to update? ");
        System.out.println("1. Date");
        System.out.println("2. Time");
        System.out.println("3. Location");
        System.out.println("4. Sport ID");
        System.out.println("5. Return to Menu");
        System.out.print("Enter your choice: ");
        int updateSchedChoice = sc.nextInt();
        switch (updateSchedChoice) {
            case 1 -> {
                System.out.println("Enter New Date: (ex. 2021-01-17) ");
                Date updateSchedDate = Date.valueOf(sc.next());
                schedule.setSchedDate(updateSchedDate);
            }
            case 2 -> {
                System.out.println("Enter New Time: (ex. 11:00:00) ");
                Time updateSchedTime = Time.valueOf(sc.next());
                schedule.setSchedTime(updateSchedTime);
            }
            case 3 -> {
                System.out.println("Enter New Location: ");
                String updateLocation = sc.next();
                schedule.setLocation(updateLocation);
            }
            case 4 -> {
                displayDA.displaySport();
                System.out.println("Enter New Sport ID: ");
                int updateSport = sc.nextInt();
                schedule.setSportID(updateSport);
            }
            case 5 -> {
                try {
                    coordinator();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
            default -> System.out.println("Invalid choice. Please try again.");
        }
        dataAccess.updateSchedule(schedule);
        System.out.println("Updated Details");
        displayDA.displaySchedSpecificToCoordinator();
    }

    public static void updateStudents() {
        displayDA.displaySpecificStudentDetails();
        Student student;
        try {
            student = dataAccess.getStudentsByCode(studentID);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        if (student == null) {
            System.out.println("Student not found.");
            return;
        }
        System.out.println("What do you want to update?");
        System.out.println("1. Password");
        System.out.println("2. Contact Number");
        System.out.println("3. Return to Menu");
        System.out.println("Enter your choice: ");
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Enter New Password: (Password must be 8 characters) ");
                String newStudPass = sc.next();
                student.setStudPassword(newStudPass);
                break;
            case 2:
                System.out.println("Enter New Contact Number: (Please enter 11 numbers) ");
                String newStudConNum = sc.next();
                student.setStudContactNumber(newStudConNum);
                break;
            case 3:
                try {
                    student();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
        dataAccess.updateStudent(student);
        System.out.println("Updated Student Details");
        displayDA.displaySpecificStudentDetails();
    }

    public static void updateTryout() throws Exception {
        displayDA.displayAllTryoutsSpecificToCoordinator();
        boolean tryouts = dataAccess.checkTryouts(coordID);
        if (!tryouts) {
            return;
        }
        System.out.print("Enter Tryout ID: ");
        int updateTryoutID = sc.nextInt();
        int coordinatorID = dataAccess.getTryoutByCoordinatorID(updateTryoutID);
        if (coordinatorID != coordID) {
            System.out.println("Tryout already handled by a Coordinator.");
            return;
        }
        Tryout tryout = dataAccess.getTryoutsByID(updateTryoutID);
        if (tryout == null) {
            System.out.println("Tryout not found.");
            return;
        }
        System.out.println("What do you want to update?");
        System.out.println("1. Tryout Result");
        System.out.println("Enter your choice: ");
        int choice = sc.nextInt();
        if (choice == 1) {
            System.out.println("Enter New Tryout Result: ");
            String updateTryResult = sc.next();
            tryout.setResult(updateTryResult);
        } else {
            System.out.println("Invalid choice. Please try again.");
            return;
        }
        dataAccess.updateTryout(tryout);
        System.out.println("Updated Tryout Details");
        displayDA.displayAllTryoutsSpecificToCoordinator();
    }

    public static void updateSport() throws SQLException {
        displayDA.displaySport();
        System.out.println("Enter Sport ID: ");
        int sportID = sc.nextInt();
        Sport sports = dataAccess.getSportByID(sportID);
        if (sports == null) {
            System.out.println("Sport not found.");
            return;
        }
        System.out.println("What do you want to update?");
        System.out.println("1. Sport Code");
        System.out.println("2. Sport Name");
        System.out.println("3. Category");
        System.out.println("Enter your choice: ");
        int choice = sc.nextInt();
        switch (choice) {
            case 1 -> {
                System.out.println("Enter New Sport Code: (ex. BB) ");
                String newSportCode = sc.next();
                sports.setSportCode(newSportCode);
            }
            case 2 -> {
                System.out.println("Enter New Sport Name: (ex. Basketball) ");
                String newSportName = sc.next();
                sports.setSportName(newSportName);
            }
            case 3 -> {
                System.out.println("Enter New Category: (Men/Women/All) ");
                String newCategory = sc.next();
                if (newCategory.equals("All") || newCategory.equals("Women") || newCategory.equals("Men")) {
                    sports.setCategory(newCategory);
                } else {
                    System.out.println("Invalid category. Only 'All', 'Women', and 'Men' are allowed. - Case-Sensitive ");
                }
            }
            default -> System.out.println("Invalid choice. Please try again.");
        }
        dataAccess.updateSport(sports);
    }
}