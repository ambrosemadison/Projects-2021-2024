package Main;

import DataAccess.dataAccess;

import Object.Student;
import Object.Coordinator;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import DataAccess.addDA;
import DataAccess.deleteDA;
import DataAccess.updateDA;
import DataAccess.searchDA;
import DataAccess.displayDA;

import static DataAccess.dataAccess.*;

public class Main {
    public static int coordID, studentID;
    public static Scanner input = new Scanner(System.in);
    public static void main(String[] args) throws Exception {
        dataAccess.setConnection();
        System.out.println("==============================================================");
        System.out.println("                Welcome to the Louisian Sports!");
        System.out.println("==============================================================");
        menu();
    }//end of main

    public static void menu() throws Exception {
        System.out.println("Choose what to do: ");
        System.out.println("1. Register");
        System.out.println("2. Login");
        System.out.println("3. Exit the Program");
        System.out.print("\nEnter your choice: ");
        int choice = input.nextInt();
        switch (choice) {
            case 1 -> register();
            case 2 -> login();
            case 3 -> {
                System.out.println("Thank you for using the program! Have a nice day!");
                System.exit(0);
            }
            default -> {
                System.out.println("--- Please enter 1 - 3 only. ---\n");
                menu();
            }
        }
    }

    public static void register() throws Exception {
        System.out.println("Register");
        System.out.println("--------------------------------------------------------------");
        System.out.println("What type of account do you want to register?: ");
        System.out.println("1. Coordinator");
        System.out.println("2. Student");
        System.out.println("3. Back");
        System.out.println("\nEnter your choice: ");
        int registerChoice = input.nextInt();
        switch (registerChoice){
            case 1 -> coordinatorRegister();
            case 2 -> studentRegister();
            case 3 -> {
                try {
                    menu();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }//end of register

    public static void login() throws Exception {
        System.out.println("Login");
        System.out.println("--------------------------------------------------------------");
        System.out.println("What do you want to do?");
        System.out.println("1. Login as Coordinator");
        System.out.println("2. Login as Student");
        System.out.println("3. Back");
        System.out.println("\nEnter your choice: ");
        int loginChoice = input.nextInt();
        switch (loginChoice){
            case 1 -> coordinatorLogin();
            case 2 -> studentLogin();
            case 3 -> {
                try {
                    menu();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }//end of login

    public static void studentRegister(){
        System.out.println("---------------------------------------");
        System.out.println("            Register Student");
        System.out.println("---------------------------------------");
        System.out.println();
        System.out.println("Enter Student First Name: ");
        String studFirstName = input.next();
        System.out.println("Enter Student Middle Name: ");
        String studMiddleName = input.next();
        System.out.println("Enter Student Last Name: ");
        String studLastName = input.next();
        String studPassword = ""; // initialize student password
        while (studPassword.length() != 8) { // validation for student password
            System.out.println("Enter Password: (Password must be 8 characters long) ");
            studPassword = input.next();
            if (studPassword.length() != 8) {
                System.out.println("***Please make sure your password is 8 characters long.\n");
            }
        }
        System.out.println("Enter E-mail: ");
        String studEmail = input.next();
        String studContactNumber = ""; // initialize student contact number
        while (studContactNumber.length() != 11) { //validation for student contact number
            System.out.println("Enter Contact Number: (Please enter 11 numbers) ");
            studContactNumber = input.next();
            if (studContactNumber.length() != 11) {
                System.out.println("***Please make sure that your contact number is 11 characters long.\n");
            }
        }
        System.out.println();
        Student registerStudent = new Student(0, studFirstName, studMiddleName, studLastName, studPassword, studEmail, studContactNumber);
        dataAccess.createStudent(registerStudent);
    }//end student register

    public static void studentLogin() throws Exception {
        System.out.println("Login as Student");
        System.out.println("--------------------------------------------------------------");
        System.out.println("Enter e-mail: ");
        String studentEmail = input.next();
        System.out.println("Enter password: ");
        String studentPassword = input.next();
        PreparedStatement stmt = connection.prepareStatement("SELECT studentID FROM student WHERE studEmail = ? AND studPassword = ?");
        stmt.setString(1, studentEmail);
        stmt.setString(2, studentPassword);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()){
            studentID = rs.getInt(1);
            System.out.println("Student Logged In.");
        }else {
            System.out.println("Invalid username or password. Please try again.");
            studentLogin();
        }
        student();
    }


    public static void coordinatorRegister() throws Exception {
        System.out.println("---------------------------------------");
        System.out.println("           Register Coordinator");
        System.out.println("---------------------------------------");
        System.out.println();
        System.out.println("Enter School: (Please only enter the code [ex. SEA]) ");
        String school = input.next();
        System.out.println("Enter Coordinator First Name: ");
        String coordinatorFirstName = input.next();
        System.out.println("Enter Coordinator Middle Name: ");
        String coordinatorMiddleName = input.next();
        System.out.println("Enter Coordinator Last Name: ");
        String coordinatorLastName = input.next();
        String coordinatorPassword = "";//initialize coordinator password
        while (coordinatorPassword.length() != 8) { //validation for coordinator password
            System.out.println("Enter Password: (Password must not be less than but must be 8 characters long) ");
            coordinatorPassword = input.next();
            if (coordinatorPassword.length() != 8) {
                System.out.println("***Please make sure that your password is 8 characters long.\n");
            }
        }
        System.out.println("Enter E-mail: ");
        String coordinatorEmail = input.next();
        String coordinatorContactNumber = ""; //initialize coordinator contact Number
        while (coordinatorContactNumber.length() != 11) { //validation for coordinator contact number
            System.out.println("Enter Contact Number: (Please enter 11 numbers)  ");
            coordinatorContactNumber = input.next();
            if (coordinatorContactNumber.length() != 11) {
                System.out.println("***Please make sure that your Contact Number is 11 characters long.\n");
            }
        }
        System.out.println();
        Coordinator registerCoordinator = new Coordinator(0,school, coordinatorFirstName, coordinatorMiddleName, coordinatorLastName, coordinatorPassword, coordinatorEmail, coordinatorContactNumber);
        dataAccess.createCoordinator(registerCoordinator);
    }//end of coordinator register

    public static void coordinatorLogin() throws Exception {
        System.out.println("Login as Coordinator");
        System.out.println("--------------------------------------------------------------");
        System.out.println("Enter e-mail: ");
        String coordinatorEmail = input.next();
        System.out.println("Enter password: ");
        String coordinatorPassword = input.next();
        PreparedStatement stmt = connection.prepareStatement("SELECT coordinatorID FROM coordinator WHERE coordEmail = ? AND coordPassword = ?");
        stmt.setString(1, coordinatorEmail);
        stmt.setString(2, coordinatorPassword);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()){
            coordID = rs.getInt(1);
            System.out.println("Coordinator Logged In.");
        } else {
            System.out.println("Invalid username or password. Please try again.");
            coordinatorLogin();
        }
       coordinator();
    }

    public static void coordinator() throws Exception {
        System.out.println("=============================================================================================================");
        System.out.println("                                                 COORDINATOR");
        System.out.println("-------------------------------------------------------------------------------------------------------------");
        System.out.println("-----------------------");
        System.out.println("|  Choose what to do  |");
        System.out.println("-----------------------");
        System.out.println("1. Create a Sport");
        System.out.println("2. Create a Schedule");
        System.out.println("3. View Details of All Coordinators");
        System.out.println("4. View Details of All Sports");
        System.out.println("5. View Details of All Schedules");
        System.out.println("6. View Details of All Students");
        System.out.println("7. View Details of All Tryouts");
        System.out.println("8. Update Coordinator Information");
        System.out.println("9. Update Detail/s of a Sport");
        System.out.println("10. Update Detail/s of a Schedule");
        System.out.println("11. Update Detail/s of a Tryout");
        System.out.println("12. Delete a Coordinator from the List");
        System.out.println("13. Delete a Sport from the List");
        System.out.println("14. Delete a Schedule from the List");
        System.out.println("15. Delete a Student from the List");
        System.out.println("16. Delete a Tryout from the List");
        System.out.println("17. Search a Student by Student ID" );
        System.out.println("18. Return to Main Menu");
        System.out.println("19. Exit Program\n");
        System.out.print("Enter choice: ");
        int coordinatorChoice = input.nextInt();
        {
            switch (coordinatorChoice) {
                case 1: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Create a Sport");
                    System.out.println("-------------------------------------------------------");
                    addDA.addSport();
                    break;
                }

                case 2: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Create a Schedule");
                    System.out.println("-------------------------------------------------------");
                    addDA.addSchedules();
                    break;
                }

                case 3: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("View Details of All Coordinators");
                    System.out.println("-------------------------------------------------------");
                    displayDA.displayCoordinator();
                    break;
                }

                case 4: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("View Details of All Sports");
                    System.out.println("-------------------------------------------------------");
                    displayDA.displaySport();
                    break;
                }

                case 5: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("View Details of All Schedules");
                    System.out.println("-------------------------------------------------------");
                    displayDA.displaySchedule();
                    break;
                }

                case 6: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("View Details of All Students");
                    System.out.println("-------------------------------------------------------");
                    displayDA.displayStudents();
                    break;
                }

                case 7: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("View Details of Tryouts");
                    System.out.println("-------------------------------------------------------");
                    displayDA.displayTryout();
                    break;
                }

                case 8: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Update Coordinator Information");
                    System.out.println("-------------------------------------------------------");
                    updateDA.updateCoordinator();
                    break;
                }

                case 9: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Update Detail/s of a Sport");
                    System.out.println("-------------------------------------------------------");
                    updateDA.updateSport();
                    break;
                }

                case 10: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Update Detail/s of a Schedule");
                    System.out.println("-------------------------------------------------------");
                    updateDA.updateSchedule();
                    break;
                }

                case 11: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Update Detail/s of a Tryout");
                    System.out.println("-------------------------------------------------------");
                    updateDA.updateTryout();
                    break;
                }

                case 12: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Delete a Coordinator from the List");
                    System.out.println("-------------------------------------------------------");
                    deleteDA.deleteCoordinator();
                    break;
                }

                case 13: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Delete a Sport from the List");
                    System.out.println("-------------------------------------------------------");
                    deleteDA.deleteSport();
                    break;
                }

                case 14: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Delete a Schedule from the List");
                    System.out.println("-------------------------------------------------------");
                    deleteDA.deleteSchedules();
                    break;
                }

                case 15: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Delete a Student from the List");
                    System.out.println("-------------------------------------------------------");
                    deleteDA.deleteStudent();
                    break;
                }

                case 16: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Delete a Tryout from the List");
                    System.out.println("-------------------------------------------------------");
                    deleteDA.deleteTryout();
                    break;
                }

                case 17: {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Search a Student by Student ID");
                    System.out.println("-------------------------------------------------------");
                    searchDA.searchStudentsByStudentID();
                    break;
                }

                case 18: menu();

                case 19: {
                    System.out.println("Thank you for using the program! Have a nice day!");
                    System.exit(0);
                }
                default: {
                    System.out.println("--- Please enter choice 1 - 19 only. ---\n");
                    coordinator();
                }
            }
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------\n\n");
            coordinator();
        }
    }// end of coordinators

    public static void student() throws Exception {
        System.out.println("=============================================================================================================");
        System.out.println("                                                  STUDENTS");
        System.out.println("-------------------------------------------------------------------------------------------------------------");
        System.out.println("-----------------------");
        System.out.println("|  Choose what to do  |");
        System.out.println("-----------------------");
        System.out.println("1. Update Student Information");
        System.out.println("2. Join a Tryout");
        System.out.println("3. View Details of All Sports");
        System.out.println("4. View Details of All Schedules");
        System.out.println("5. View Details of My Tryouts");
        System.out.println("6. Search a Coordinator by Coordinator ID");
        System.out.println("7. Search a Sport by Sport ID");
        System.out.println("8. Search a Schedule");
        System.out.println("9. Return to Main Menu");
        System.out.println("10. Exit Program\n");
        System.out.print("Enter your choice: ");
        int studentChoice = input.nextInt();
        {
            switch (studentChoice) {
                case 1 -> {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Update Student Information");
                    System.out.println("-------------------------------------------------------");
                    updateDA.updateStudents();
                }
                case 2 -> {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Join a Tryout");
                    System.out.println("-------------------------------------------------------");
                    addDA.addTryoutForStudent();
                }
                case 3 -> {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("View Details of All Sports");
                    System.out.println("-------------------------------------------------------");
                    displayDA.displaySport();
                }
                case 4 -> {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("View Details of All Schedules");
                    System.out.println("-------------------------------------------------------");
                    displayDA.displaySchedule();
                }
                case 5 -> {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("View Details of My Tryouts");
                    System.out.println("-------------------------------------------------------");
                    displayDA.displaySpecificTryout();
                }
                case 6 -> {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Search a Coordinator by their Coordinator ID");
                    System.out.println("-------------------------------------------------------");
                    searchDA.searchCoordinatorByCoordinatorID();
                }
                case 7 -> {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Search a Sport by their Sport ID");
                    System.out.println("-------------------------------------------------------");
                    searchDA.searchSportBySportID();
                }
                case 8 -> {
                    System.out.println("-------------------------------------------------------");
                    System.out.println("Search a Schedule");
                    System.out.println("-------------------------------------------------------");
                    searchDA.searchSchedulesByScheduleID();
                }
                case 9 -> menu();
                case 10 -> {
                    System.out.println("Thank you for using the program! Have a nice day!");
                    System.exit(0);
                }
                default -> {
                    System.out.println("--- Please enter choice 1 - 11 only. ---\n");
                    student();
                }
            }
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------\n\n");
            student();
        }
    }//end of students
}