package Object;

public class Coordinator {
    private int coordinatorID;
    private String school;
    private String coordFirstName;
    private String coordMiddleName;
    private String coordLastName;
    private String coordPassword;
    private String coordEmail;
    private String coordContactNumber;

    public Coordinator() {
    }

    public Coordinator(int coordinatorID, String school, String coordFirstName,
                       String coordMiddleName, String coordLastName, String coordPassword, String coordEmail,
                       String coordContactNumber) {
        this.coordinatorID = coordinatorID;
        this.school = school;
        this.coordFirstName = coordFirstName;
        this.coordMiddleName = coordMiddleName;
        this.coordLastName = coordLastName;
        this.coordPassword = coordPassword;
        this.coordEmail = coordEmail;
        this.coordContactNumber = coordContactNumber;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public int getCoordinatorID() {
        return coordinatorID;
    }

    public void setCoordinatorID(int coordinatorID) {
        this.coordinatorID = coordinatorID;
    }

    public String getCoordLastName() {
        return coordLastName;
    }

    public void setCoordLastName(String coordLastName) {
        this.coordLastName = coordLastName;
    }

    public String getCoordFirstName() {
        return coordFirstName;
    }

    public void setCoordFirstName(String coordFirstName) {
        this.coordFirstName = coordFirstName;
    }

    public String getCoordMiddleName() {
        return coordMiddleName;
    }

    public String getCoordPassword() {
        return coordPassword;
    }

    public void setCoordPassword(String coordPassword) {
        this.coordPassword = coordPassword;
    }

    public String getCoordEmail() {
        return coordEmail;
    }

    public void setCoordEmail(String coordEmail) {
        this.coordEmail = coordEmail;
    }

    public String getCoordContactNumber() {
        return coordContactNumber;
    }

    public void setCoordContactNumber(String coordContactNumber) {
        this.coordContactNumber = coordContactNumber;
    }
}
