package Object;

import java.sql.Time;
import java.sql.Date;

public class Schedule {
    private int scheduleID;
    private Date schedDate;
    private Time schedTime;
    private String location;
    private int sportID;
    private String sportName;
    private String category;
    private int coordinatorID;
    private String coordinatorFirstName;
    private String coordinatorLastName;
    private String school;

    public Schedule(int scheduleID, Date schedDate, Time schedTime, String location, int sportID, String sportName, String category, int coordinatorID, String coordinatorFirstName, String coordinatorLastName, String school) {
        this.scheduleID = scheduleID;
        this.schedDate = schedDate;
        this.schedTime = schedTime;
        this.location = location;
        this.sportID = sportID;
        this.sportName = sportName;
        this.category = category;
        this.coordinatorID = coordinatorID;
        this.coordinatorFirstName = coordinatorFirstName;
        this.coordinatorLastName = coordinatorLastName;
        this.school = school;
    }

    public Schedule() {
    }

    public Schedule(int scheduleID, Date schedDate, Time schedTime, String location, int sportID, int coordinatorID) {
        this.scheduleID = scheduleID;
        this.schedDate = schedDate;
        this.schedTime = schedTime;
        this.location = location;
        this.sportID = sportID;
        this.coordinatorID = coordinatorID;
    }

    public int getScheduleID() {
        return scheduleID;
    }

    public void setScheduleID(int scheduleID) {
        this.scheduleID = scheduleID;
    }

    public Date getSchedDate() {
        return schedDate;
    }

    public void setSchedDate(Date schedDate) {
        this.schedDate = schedDate;
    }

    public Time getSchedTime() {
        return schedTime;
    }

    public void setSchedTime(Time schedTime) {
        this.schedTime = schedTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getCoordinatorID() {
        return coordinatorID;
    }

    public void setCoordinatorID(int coordinatorID) {
        this.coordinatorID = coordinatorID;
    }

    public int getSportID() {
        return sportID;
    }

    public void setSportID(int sportID) {
        this.sportID = sportID;
    }

    public String getSportName() {
        return sportName;
    }

    public void setSportName(String sportName) {
        this.sportName = sportName;
    }

    public String getCoordinatorFirstName() {
        return coordinatorFirstName;
    }

    public void setCoordinatorFirstName(String coordinatorFirstName) {
        this.coordinatorFirstName = coordinatorFirstName;
    }

    public String getCoordinatorLastName() {
        return coordinatorLastName;
    }

    public void setCoordinatorLastName(String coordinatorLastName) {
        this.coordinatorLastName = coordinatorLastName;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public Object getCategory() {
        return category;
    }

    public Object getSchool() {
        return school;
    }
}
