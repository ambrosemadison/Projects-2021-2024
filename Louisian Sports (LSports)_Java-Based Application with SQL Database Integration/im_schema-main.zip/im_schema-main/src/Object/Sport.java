package Object;

public class Sport {
    private int sportID;
    private String sportCode;
    private String sportName;
    private String category;

    public Sport() {
    }

    public Sport(int sportID, String sportCode, String sportName, String category) {
        this.sportID = sportID;
        this.sportCode = sportCode;
        this.sportName = sportName;
        this.category = category;
    }

    public int getSportID() {
        return sportID;
    }

    public void setSportID(int sportID) {
        this.sportID = sportID;
    }

    public String getSportCode() {
        return sportCode;
    }

    public void setSportCode(String sportCode) {
        this.sportCode = sportCode;
    }

    public String getSportName() {
        return sportName;
    }

    public void setSportName(String sportName) {
        this.sportName = sportName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}

