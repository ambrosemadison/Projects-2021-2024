package Object;

public class Student {
    private int studentID;
    private String studFirstName;
    private String studMiddleName;
    private String studLastName;
    private String studPassword;
    private String studEmail;
    private String studContactNumber;

    public Student() {
    }

    public Student(int studentID, String studFirstName, String studMiddleName, String studLastName,
                   String studPassword, String studEmail, String studContactNumber) {
        this.studentID = studentID;
        this.studFirstName = studFirstName;
        this.studMiddleName = studMiddleName;
        this.studLastName = studLastName;
        this.studPassword = studPassword;
        this.studEmail = studEmail;
        this.studContactNumber = studContactNumber;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getStudFirstName() {
        return studFirstName;
    }

    public void setStudFirstName(String studFirstName) {
        this.studFirstName = studFirstName;
    }

    public String getStudMiddleName() {
        return studMiddleName;
    }

    public void setStudMiddleName(String studMiddleName) {
        this.studMiddleName = studMiddleName;
    }
    public String getStudLastName() {
        return studLastName;
    }

    public void setStudLastName(String studLastName) {
        this.studLastName = studLastName;
    }

    public String getStudPassword() {
        return studPassword;
    }

    public void setStudPassword(String studPassword) {
        this.studPassword = studPassword;
    }

    public String getStudEmail() {
        return studEmail;
    }

    public void setStudEmail(String studEmail) {
        this.studEmail = studEmail;
    }

    public String getStudContactNumber() {
        return studContactNumber;
    }

    public void setStudContactNumber(String studContactNumber) {
        this.studContactNumber = studContactNumber;
    }
}
