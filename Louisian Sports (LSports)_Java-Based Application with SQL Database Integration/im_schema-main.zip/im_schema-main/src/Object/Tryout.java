package Object;

import java.sql.Date;
import java.sql.Time;

public class Tryout {
    private int tryoutID;
    private int scheduleID;
    private Date schedDate;
    private Time schedTime;
    private String location;
    private int studentID;
    private String studLastName;
    private String studFirstname;
    private String sportName;
    private String category;
    private String result;

    public Tryout(int tryoutID, int scheduleID, int studentID, String result) {
        this.tryoutID = tryoutID;
        this.scheduleID = scheduleID;
        this.studentID = studentID;
        this.result = result;
    }

    public Tryout() {
    }

    public Tryout(int tryoutID, Date schedDate, Time schedTime, String location, int studentID, String studLastName,
                  String studFirstname, String sportName, String category, String result) {
        this.tryoutID = tryoutID;
        this.schedDate = schedDate;
        this.schedTime = schedTime;
        this.location = location;
        this.studentID = studentID;
        this.studLastName = studLastName;
        this.studFirstname = studFirstname;
        this.sportName = sportName;
        this.category = category;
        this.result = result;
    }

    public int getTryoutID() {
        return tryoutID;
    }

    public void setTryoutID(int tryoutID) {
        this.tryoutID = tryoutID;
    }

    public int getScheduleID() {
        return scheduleID;
    }

    public void setScheduleID(int scheduleID) {
        this.scheduleID = scheduleID;
    }

    public Date getSchedDate() {
        return schedDate;
    }

    public Time getSchedTime() {
        return schedTime;
    }

    public String getLocation() {
        return location;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getStudLastName() {
        return studLastName;
    }

    public String getStudFirstname() {
        return studFirstname;
    }

    public String getSportName() {
        return sportName;
    }

    public String getCategory() {
        return category;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
